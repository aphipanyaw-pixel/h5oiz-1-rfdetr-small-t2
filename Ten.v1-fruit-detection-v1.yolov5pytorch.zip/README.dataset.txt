# Ten > fruit-detection-v1
https://universe.roboflow.com/aphipanyas-workspace/ten-h5oiz

Provided by a Roboflow user
License: CC BY 4.0

